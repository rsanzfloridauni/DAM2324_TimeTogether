package timetogether.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import timetogether.model.Evento;

public interface EventoRepository extends MongoRepository<Evento, String>{
	//Metodos
}

package timetogether.controller;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import javax.mail.MessagingException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import timetogether.model.Evento;
import timetogether.model.Grupo;
import timetogether.model.Tallas;
import timetogether.model.Usuario;
import timetogether.repository.EventoRepository;
import timetogether.repository.GrupoRepository;
import timetogether.repository.UsuarioRepository;

@RestController
public class Controller {

	@Autowired
	private UsuarioRepository usuarioRepository;
	@Autowired
	private GrupoRepository grupoRepository;
	@Autowired
	private EventoRepository eventoRepository;

	// Variable para almacenar la contraseña del correo electrónico
	private String mailPassword = "qkzj omtn jujl ygjk";
	// Mapa para almacenar códigos de verificación enviados a los usuarios
	private Map<String, Integer> verificationCodes = new HashMap<>();
	private Map<String, Usuario> temporalStorage = new HashMap<>();

	/**
	 * Retrieves complete user information based on email and password.
	 *
	 * @param apiInput User data in JSON format including email and password.
	 * @return ResponseEntity with user information or an error if not found.
	 */
	@PostMapping("TimeTogether/user")
	ResponseEntity<String> getUser(@RequestBody String apiInput) {
		JSONObject userData = new JSONObject(apiInput);
		Optional<Usuario> userOpt = usuarioRepository.findByMailAndPassword(userData.getString("mail"),
				userData.getString("password"));
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			JSONObject sizes = new JSONObject();
			response.put("id", user.getId());
			response.put("name", user.getName());
			response.put("groups", user.getGroups().toArray());
			response.put("additional_information", user.getAdditional_information());
			response.put("addres", user.getAddres());
			response.put("alergies", user.getAlergies());
			response.put("birthday", user.getBirthday());
			response.put("favourite_color", user.getFavourite_color());
			response.put("friends", user.getFriends().toArray());
			response.put("hobbies", user.getHobbies());
			response.put("mail", user.getMail());
			response.put("password", user.getPassword());
			response.put("profile_picture", user.getProfile_picture());
			sizes.put("shirt", user.getSizes().getShirt());
			sizes.put("trousers", user.getSizes().getTrousers());
			sizes.put("shoes", user.getSizes().getShoes());
			response.put("sizes", sizes);
			response.put("surname", user.getSurname());
			return ResponseEntity.ok(response.toString()); // Devolver usuario encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el usuario
		}
	}

	/**
	 * Retrieves complete information of a group based on its ID.
	 *
	 * @param apiInput ID of the group to search for.
	 * @return ResponseEntity with the group information or an error if not found.
	 */
	@GetMapping("TimeTogether/group")
	ResponseEntity<String> getGroup(@RequestParam(value = "id") String apiInput) {
		Optional<Grupo> groupOpt = grupoRepository.findById(apiInput);
		if (groupOpt.isPresent()) {
			Grupo group = groupOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", group.getId());
			response.put("description", group.getDescription());
			response.put("events", group.getEvents().toArray());

			JSONArray membersJson = new JSONArray();

			for (String memberId : group.getMembers()) {
				Optional<Usuario> userOpt = usuarioRepository.findById(memberId);
				if (userOpt.isPresent()) {
					Usuario usuario = userOpt.get();
					JSONObject memberInfo = new JSONObject();
					memberInfo.put("id", usuario.getId());
					memberInfo.put("name", usuario.getName());
					membersJson.put(memberInfo);
				}

			}

			response.put("members", membersJson);

			response.put("name", group.getName());
			response.put("color", group.getColor());
			return ResponseEntity.ok(response.toString());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	/**
	 * Retrieves information of an event based on its ID.
	 *
	 * @param apiInput ID of the event to search for.
	 * @return ResponseEntity with the event information or an error if not found.
	 */
	@GetMapping("TimeTogether/event")
	ResponseEntity<String> getEvent(@RequestParam(value = "id") String apiInput) {
		Optional<Evento> eventOpt = eventoRepository.findById(apiInput);
		if (eventOpt.isPresent()) {
			Evento event = eventOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", event.getId());
			response.put("date", event.getDate());
			response.put("description", event.getDescription());
			response.put("location", event.getLocation());
			response.put("name", event.getName());

			List<Grupo> allGroups = grupoRepository.findAll();
			for (Grupo group : allGroups) {
				if (group.getEvents().contains(apiInput)) { 
					JSONArray membersJson = new JSONArray();
					for (String memberId : group.getMembers()) {
						usuarioRepository.findById(memberId).ifPresent(usuario -> {
							JSONObject memberInfo = new JSONObject();
							memberInfo.put("id", usuario.getId());
							memberInfo.put("name", usuario.getName());
							membersJson.put(memberInfo);
						});
					}
					response.put("members", membersJson);
					break; 
				}
			}

			return ResponseEntity.ok(response.toString());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	/**
	 * Retrieves information of a friend based on their ID.
	 *
	 * @param apiInput ID of the friend to search for.
	 * @return ResponseEntity with the friend's information or an error if not found.
	 */
	@GetMapping("TimeTogether/friendInfo")
	ResponseEntity<String> getFriendInformation(@RequestParam(value = "id") String apiInput) {
		Optional<Usuario> userOpt = usuarioRepository.findById(apiInput);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			JSONObject sizes = new JSONObject();
			response.put("id", user.getId());
			response.put("name", user.getName());
			response.put("additional_information", user.getAdditional_information());
			response.put("addres", user.getAddres());
			response.put("alergies", user.getAlergies());
			response.put("birthday", user.getBirthday());
			response.put("favourite_color", user.getFavourite_color());
			response.put("hobbies", user.getHobbies());
			response.put("mail", user.getMail());
			response.put("profile_picture", user.getProfile_picture());
			sizes.put("shirt", user.getSizes().getShirt());
			sizes.put("trousers", user.getSizes().getTrousers());
			sizes.put("shoes", user.getSizes().getShoes());
			response.put("sizes", sizes);
			response.put("surname", user.getSurname());
			return ResponseEntity.ok(response.toString()); // Devolver usuario encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el usuario
		}

	}

	/**
	 * Retrieves the friends of a user based on their ID.
	 *
	 * @param apiInput ID of the user whose friends are being searched for.
	 * @return ResponseEntity with the list of friends or an error if not found.
	 */
	@GetMapping("TimeTogether/friends")
	ResponseEntity<String> getFriends(@RequestParam(value = "id") String apiInput) {
		Optional<Usuario> userOpt = usuarioRepository.findById(apiInput);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			JSONArray data = new JSONArray();
			List<Usuario> friends = usuarioRepository.findAllById(user.getFriends());
			for (int i = 0; i < friends.size(); i++) {
				JSONObject friendData = new JSONObject();
				friendData.put("id", friends.get(i).getId());
				friendData.put("name", friends.get(i).getName());
				friendData.put("surname", friends.get(i).getSurname());
				friendData.put("profile_picture", friends.get(i).getProfile_picture());
				data.put(friendData);
			}
			response.put("friends", data);
			return ResponseEntity.ok(response.toString()); // Devolver amigos encontrados encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el evento
		}
	}

	/**
	 * Retrieves the groups a user belongs to based on their ID.
	 *
	 * @param userId ID of the user.
	 * @return ResponseEntity with the user's groups or an error if not found.
	 */
	@GetMapping("TimeTogether/userGroups")
	public ResponseEntity<String> getUserGroups(@RequestParam(value = "userId") String userId) {
		Optional<Usuario> userOpt = usuarioRepository.findById(userId);
		if (!userOpt.isPresent()) {
			return ResponseEntity.notFound().build();
		}

		Usuario user = userOpt.get();
		List<String> groupIds = user.getGroups();
		List<Grupo> groups = new ArrayList<>();

		for (String groupId : groupIds) {
			Optional<Grupo> foundGroup = grupoRepository.findById(groupId);
			if (foundGroup.isPresent()) {
				groups.add(foundGroup.get());
			}
		}

		JSONArray groupsJsonArray = new JSONArray();
		for (Grupo group : groups) {
			JSONObject groupJson = new JSONObject();
			groupJson.put("id", group.getId());
			groupJson.put("name", group.getName());
			groupJson.put("color", group.getColor());
			groupsJsonArray.put(groupJson);
		}

		JSONObject response = new JSONObject();
		response.put("groups", groupsJsonArray);
		return ResponseEntity.ok(response.toString());
	}

	/**
	 * Retrieves the ID of a user based on their email address.
	 *
	 * @param email Email address of the user.
	 * @return ResponseEntity with the user's ID or an error if not found.
	 */
	@GetMapping("TimeTogether/userIdByEmail")
	public ResponseEntity<String> getUserIdByEmail(@RequestParam(value = "email") String email) {
		Optional<Usuario> userOpt = usuarioRepository.findByMail(email);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", user.getId());
			response.put("name", user.getName());
			return ResponseEntity.ok(response.toString());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	/**
	 * Registers a new user in the system.
	 *
	 * @param apiInput Data of the new user in JSON format.
	 * @return ResponseEntity indicating success or failure in user creation.
	 */
	@PostMapping("TimeTogether/newUser")
	ResponseEntity<String> postUser(@RequestBody String apiInput) {
		JSONObject userData = new JSONObject(apiInput);

		String mail = userData.getString("mail");
		if (usuarioRepository.findByMail(mail).isPresent()) {
			return ResponseEntity.status(HttpStatus.CONFLICT)
					.body("Ya existe un usuario con el mismo correo electrónico.");
		}
		Usuario user = new Usuario();
		user.setAdditional_information(userData.getString("additional_information"));
		user.setAddres(userData.getString("addres"));
		user.setAlergies(userData.getString("alergies"));
		user.setBirthday(userData.getString("birthday"));
		user.setFavourite_color(userData.getString("favourite_color"));
		List<String> friends = userData.getJSONArray("friends").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		user.setFriends(friends);
		user.setHobbies(userData.getString("hobbies"));
		user.setMail(mail);
		user.setName(userData.getString("name"));
		user.setPassword(userData.getString("password"));
		user.setProfile_picture(userData.getString("profile_picture"));
		JSONObject sizes = userData.getJSONObject("sizes");
		Tallas sizeData = new Tallas();
		sizeData.setShirt(sizes.getInt("shirt"));
		sizeData.setTrousers(sizes.getInt("trousers"));
		sizeData.setShoes(sizes.getInt("shoes"));
		user.setSizes(sizeData);
		user.setSurname(userData.getString("surname"));
		List<String> groups = userData.getJSONArray("groups").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		user.setGroups(groups);

		temporalStorage.put(mail, user);
		Random rand = new Random();
		int mailCode = rand.nextInt(10000) + 1;
		verificationCodes.put(user.getMail(), mailCode);
		try {
			SendMail sendMail = new SendMail(
					"Gracias por registrarte en TimeTogether! \nTu cuenta ya está casi lista, aquí tienes el código de verificación: "
							+ mailCode,
					"Codigo de verificación", "timetogether292@gmail.com", mailPassword, "smtp.gmail.com", "587",
					new String[] { user.getMail() });
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error al enviar el correo de verificación.");
		}

		return ResponseEntity.ok("Usuario creado con éxito y correo de verificación enviado.");
	}

	/**
	 * Verifies the verification code sent to the user's email.
	 *
	 * @param requestBody Data including the user's email and the verification code.
	 * @return ResponseEntity with the result of the verification.
	 */
	@PostMapping("TimeTogether/verifyCode")
	public ResponseEntity<Boolean> verifyUserCode(@RequestBody String requestBody) {
		JSONObject requestJson = new JSONObject(requestBody);
		int code = requestJson.getInt("code");
		String email = requestJson.getString("email"); 

		if (verificationCodes.containsKey(email) && verificationCodes.get(email) == code) {
			Usuario user = temporalStorage.get(email);
			usuarioRepository.save(user);
			temporalStorage.remove(email);
			verificationCodes.remove(email);
			return ResponseEntity.ok(true);
		} else {
			return ResponseEntity.ok(false);
		}
	}

	/**
	 * Creates a new group in the system.
	 *
	 * @param apiInput Data of the new group in JSON format.
	 * @return ResponseEntity indicating success or failure in the creation of the group.
	 */
	@PostMapping("TimeTogether/newGroup")
	ResponseEntity<String> postGroup(@RequestBody String apiInput) {
		JSONObject groupData = new JSONObject(apiInput);
		Grupo group = new Grupo();
		group.setDescription(groupData.getString("description"));
		List<String> events = groupData.getJSONArray("events").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		group.setEvents(events);
		List<String> members = groupData.getJSONArray("members").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		group.setMembers(members);
		group.setName(groupData.getString("name"));
		group.setColor(groupData.getString("color"));
		Grupo savedGroup = grupoRepository.save(group);

		members.forEach(memberId -> {
			Optional<Usuario> userOpt = usuarioRepository.findById(memberId);
			if (userOpt.isPresent()) {
				Usuario user = userOpt.get();
				List<String> userGroups = user.getGroups();
				if (userGroups == null) {
					userGroups = new ArrayList<>();
				}
				userGroups.add(savedGroup.getId());
				user.setGroups(userGroups);
				usuarioRepository.save(user);
			}
		});
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	/**
	 * Creates a new event in the system.
	 *
	 * @param apiInput Data of the new event in JSON format.
	 * @return ResponseEntity indicating success or failure in the creation of the event.
	 */
	@PostMapping("TimeTogether/newEvent")
	ResponseEntity<String> postEvent(@RequestBody String apiInput) {
		JSONObject eventData = new JSONObject(apiInput);
		String groupId = eventData.getString("groupId");
		Evento event = new Evento();
		event.setDate(eventData.getString("date"));
		event.setDescription(eventData.getString("description"));
		event.setLocation(eventData.getString("location"));
		event.setName(eventData.getString("name"));
		Evento ev = eventoRepository.save(event);
		Optional<Grupo> groupOpt = grupoRepository.findById(groupId);
		if(groupOpt.isPresent()) {
			Grupo group = groupOpt.get();
			List<String> events = group.getEvents();
			events.add(ev.getId());
			grupoRepository.save(group);
		}
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	/**
	 * Updates the information of an existing user.
	 *
	 * @param userId   ID of the user to be updated.
	 * @param apiInput Updated user data in JSON format.
	 * @return ResponseEntity indicating success or failure in updating the user.
	 */
	@PutMapping("TimeTogether/updateUser/{userId}")
	ResponseEntity<String> updateUser(@PathVariable String userId, @RequestBody String apiInput) {
		Optional<Usuario> userOptional = usuarioRepository.findById(userId);
		if (userOptional.isPresent()) {
			Usuario user = userOptional.get();
			JSONObject userData = new JSONObject(apiInput);

			user.setAdditional_information(
					userData.optString("additional_information", user.getAdditional_information()));
			user.setAddres(userData.optString("addres", user.getAddres()));
			user.setAlergies(userData.optString("alergies", user.getAlergies()));
			user.setBirthday(userData.optString("birthday", user.getBirthday()));
			user.setFavourite_color(userData.optString("favourite_color", user.getFavourite_color()));

			user.setHobbies(userData.optString("hobbies", user.getHobbies()));
			user.setMail(userData.optString("mail", user.getMail()));
			user.setName(userData.optString("name", user.getName()));

			user.setProfile_picture(userData.optString("profile_picture", user.getProfile_picture()));

			JSONObject sizes = userData.getJSONObject("sizes");
			Tallas sizeData = user.getSizes();
			sizeData.setShirt(sizes.optInt("shirt", sizeData.getShirt()));
			sizeData.setTrousers(sizes.optInt("trousers", sizeData.getTrousers()));
			sizeData.setShoes(sizes.optInt("shoes", sizeData.getShoes()));
			user.setSizes(sizeData);

			user.setSurname(userData.optString("surname", user.getSurname()));

			usuarioRepository.save(user);
			return ResponseEntity.ok().build();
		} else {
			return ResponseEntity.badRequest().body("No se ha podido actualizar el usuario");
		}
	}

	/**
	 * Retrieves the events a user is participating in on a specific date.
	 *
	 * @param requestBody Data including the user's ID and the date of the events.
	 * @return ResponseEntity with the user's events on the given date or an error if not found.
	 */
	@PostMapping("TimeTogether/eventsByUserAndDate")
	public ResponseEntity<String> getEventsByUserAndDate(@RequestBody String requestBody) {
		JSONObject request = new JSONObject(requestBody);
		String userId = request.getString("userId");
		String dateString = request.getString("date");
		Optional<Usuario> userOpt = usuarioRepository.findById(userId);
		if (!userOpt.isPresent()) {
			return ResponseEntity.notFound().build();
		}

		Usuario user = userOpt.get();
		List<String> userGroups = user.getGroups();
		List<Evento> allEvents = new ArrayList<>();
		List<String> colors = new ArrayList<String>();
		Map<String, String> groupColors = new HashMap<>();

		for (String groupId : userGroups) {
			Optional<Grupo> groupOpt = grupoRepository.findById(groupId);
			groupOpt.ifPresent(grupo -> {
				List<String> eventIds = grupo.getEvents();
				for (String eventId : eventIds) {
					Optional<Evento> eventOpt = eventoRepository.findById(eventId);
					eventOpt.ifPresent(evento -> {
						if (evento.getDate().equals(dateString)) {
							allEvents.add(evento);
							colors.add(grupo.getColor());
						}
					});
				}
			});
		}

		JSONArray eventsJsonArray = new JSONArray();
		int cont = 0;
		for (Evento event : allEvents) {
			JSONObject eventJson = new JSONObject();
			eventJson.put("id", event.getId());
			eventJson.put("name", event.getName());

			eventJson.put("groupColor", colors.get(cont));
			eventsJsonArray.put(eventJson);
			cont++;
		}

		JSONObject response = new JSONObject();
		response.put("events", eventsJsonArray);

		return ResponseEntity.ok(response.toString());
	}

	/**
	 * Adds a group to the specified users by name.
	 *
	 * @param requestBody Data including the name of the group and the IDs of the users.
	 * @return ResponseEntity indicating success or failure in adding the group to the users.
	 */
	@PostMapping("TimeTogether/addGroupToUsers")
	public ResponseEntity<String> addGroupToUsersByName(@RequestBody String requestBody) {
		try {
			JSONObject requestJson = new JSONObject(requestBody);
			String groupName = requestJson.getString("groupName");
			JSONArray userIds = requestJson.getJSONArray("userIds");
			List<String> userIdList = userIds.toList().stream().map(Object::toString).collect(Collectors.toList());

			Optional<Grupo> groupOpt = grupoRepository.findByName(groupName);
			if (!groupOpt.isPresent()) {
				return ResponseEntity.badRequest().body("Grupo no encontrado con el nombre: " + groupName);
			}

			String groupId = groupOpt.get().getId();
			List<Usuario> usersToUpdate = new ArrayList<>();
			for (String userId : userIdList) {
				Optional<Usuario> userOpt = usuarioRepository.findById(userId);
				if (userOpt.isPresent()) {
					Usuario user = userOpt.get();
					List<String> groups = user.getGroups();
					if (!groups.contains(groupId)) {
						groups.add(groupId);
						user.setGroups(groups);
						usersToUpdate.add(user);
					}
				} else {
					return ResponseEntity.badRequest().body("Usuario no encontrado con el ID: " + userId);
				}
			}

			if (!usersToUpdate.isEmpty()) {
				usuarioRepository.saveAll(usersToUpdate);
				return ResponseEntity.ok("Grupo '" + groupName + "' agregado exitosamente a los usuarios.");
			} else {
				return ResponseEntity.ok("No se realizaron cambios.");
			}
		} catch (Exception e) {
			return ResponseEntity.badRequest().body("Error en el formato de la solicitud: " + e.getMessage());
		}
	}

	/**
	 * Adds a user to the friend list of the user based on the user's id and the friend's email.
	 * @param apiInput User id (userId) and friend's email (mail) in JSON format.
	 * @return ResponseEntity indicating success or failure in adding the friend.
	 */
	@PostMapping("TimeTogether/addFriend")
	public ResponseEntity<String> addFriend(@RequestBody String apiInput) {
		JSONObject requestJson = new JSONObject(apiInput);
		String userId = requestJson.getString("userId");
		String friendMail = requestJson.getString("friendMail");

		Optional<Usuario> userOpt = usuarioRepository.findById(userId);
		Optional<Usuario> friendOpt = usuarioRepository.findByMail(friendMail);

		if (!userOpt.isPresent()) {
			return ResponseEntity.badRequest().body("Usuario no encontrado con el ID: " + userId);
		}
		if (!friendOpt.isPresent()) {
			return ResponseEntity.badRequest().body("Amigo no encontrado con el mail: " + friendMail);
		}

		Usuario user = userOpt.get();
		Usuario friend = friendOpt.get();

		if (user.getFriends().contains(friend.getId())) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("El amigo ya está en la lista de amigos.");
		}

		user.getFriends().add(friend.getId());
		usuarioRepository.save(user);

		return ResponseEntity.ok().build();
	}

	/**
	 * Removes a friend from the user's friend list based on the user's id and the friend's id.
	 * @param apiInput User id (userId) and friend's id (friendId) in JSON format.
	 * @return ResponseEntity indicating success or failure in removing the friend.
	 */
	@PostMapping("TimeTogether/removeFriend")
	public ResponseEntity<String> removeFriend(@RequestBody String apiInput) {
		JSONObject requestJson = new JSONObject(apiInput);
		String userId = requestJson.getString("userId");
		String friendId = requestJson.getString("friendId");

		Optional<Usuario> userOpt = usuarioRepository.findById(userId);
		if (!userOpt.isPresent()) {
			return ResponseEntity.badRequest().body("Usuario no encontrado con el ID: " + userId);
		}

		Usuario user = userOpt.get();
		List<String> friends = user.getFriends();

		if (!friends.contains(friendId)) {
			return ResponseEntity.badRequest().body("El amigo con ID: " + friendId + " no está en la lista de amigos.");
		}

		friends.remove(friendId);
		user.setFriends(friends);
		usuarioRepository.save(user);

		return ResponseEntity.ok().build();
	}

}

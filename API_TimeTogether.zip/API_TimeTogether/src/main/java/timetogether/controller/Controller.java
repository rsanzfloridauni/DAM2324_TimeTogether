package timetogether.controller;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import timetogether.model.Evento;
import timetogether.model.Grupo;
import timetogether.model.Tallas;
import timetogether.model.Usuario;
import timetogether.repository.EventoRepository;
import timetogether.repository.GrupoRepository;
import timetogether.repository.UsuarioRepository;

@RestController
public class Controller {

	@Autowired
	private UsuarioRepository usuarioRepository;
	@Autowired
	private GrupoRepository grupoRepository;
	@Autowired
	private EventoRepository eventoRepository;

	@PostMapping("TimeTogether/user")
	ResponseEntity<String> getUser(@RequestBody String apiInput) {
		JSONObject userData = new JSONObject(apiInput);
		Optional<Usuario> userOpt = usuarioRepository.findByMailAndPassword(userData.getString("mail"),
				userData.getString("password"));
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			JSONObject sizes = new JSONObject();
			response.put("id", user.getId());
			response.put("name", user.getName());
			response.put("groups", user.getGroups().toArray());
			response.put("additional_information", user.getAdditional_information());
			response.put("addres", user.getAddres());
			response.put("alergies", user.getAlergies());
			response.put("birthday", user.getBirthday());
			response.put("favourite_color", user.getFavourite_color());
			response.put("friends", user.getFriends().toArray());
			response.put("hobbies", user.getHobbies());
			response.put("mail", user.getMail());
			response.put("password", user.getPassword());
			response.put("profile_picture", user.getProfile_picture());
			sizes.put("shirt", user.getSizes().getShirt());
			sizes.put("trousers", user.getSizes().getTrousers());
			sizes.put("shoes", user.getSizes().getShoes());
			response.put("sizes", sizes);
			response.put("surname", user.getSurname());
			return ResponseEntity.ok(response.toString()); // Devolver usuario encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el usuario
		}
	}

	@GetMapping("TimeTogether/group")
	ResponseEntity<String> getGroup(@RequestParam(value = "id") String apiInput) {
		Optional<Grupo> groupOpt = grupoRepository.findById(apiInput);
		if (groupOpt.isPresent()) {
			Grupo group = groupOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", group.getId());
			response.put("description", group.getDescription());
			response.put("events", group.getEvents().toArray());
			response.put("members", group.getEvents().toArray());
			response.put("name", group.getName());
			response.put("color", group.getColor());
			return ResponseEntity.ok(response.toString()); // Devolver grupo encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el grupo
		}
	}

	@GetMapping("TimeTogether/event")
	ResponseEntity<String> getEvent(@RequestParam(value = "id") String apiInput) {
		Optional<Evento> eventOpt = eventoRepository.findById(apiInput);
		if (eventOpt.isPresent()) {
			Evento event = eventOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", event.getId());
			response.put("date", event.getDate());
			response.put("description", event.getDescription());
			response.put("location", event.getLocation());
			response.put("name", event.getName());
			return ResponseEntity.ok(response.toString()); // Devolver evento encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el evento
		}

	}

	@GetMapping("TimeTogether/friendInfo")
	ResponseEntity<String> getFriendInformation(@RequestParam(value = "id") String apiInput) {
		Optional<Usuario> userOpt = usuarioRepository.findById(apiInput);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			JSONObject sizes = new JSONObject();
			response.put("id", user.getId());
			response.put("name", user.getName());
			response.put("additional_information", user.getAdditional_information());
			response.put("addres", user.getAddres());
			response.put("alergies", user.getAlergies());
			response.put("birthday", user.getBirthday());
			response.put("favourite_color", user.getFavourite_color());
			response.put("hobbies", user.getHobbies());
			response.put("mail", user.getMail());
			response.put("profile_picture", user.getProfile_picture());
			sizes.put("shirt", user.getSizes().getShirt());
			sizes.put("trousers", user.getSizes().getTrousers());
			sizes.put("shoes", user.getSizes().getShoes());
			response.put("sizes", sizes);
			response.put("surname", user.getSurname());
			return ResponseEntity.ok(response.toString()); // Devolver usuario encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el usuario
		}

	}

	@GetMapping("TimeTogether/friends")
	ResponseEntity<String> getFriends(@RequestParam(value = "id") String apiInput) {
		Optional<Usuario> userOpt = usuarioRepository.findById(apiInput);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			JSONArray data = new JSONArray();
			List<Usuario> friends = usuarioRepository.findAllById(user.getFriends());
			for (int i = 0; i < friends.size(); i++) {
				JSONObject friendData = new JSONObject();
				friendData.put("id", friends.get(i).getId());
				friendData.put("name", friends.get(i).getName());
				friendData.put("surname", friends.get(i).getSurname());
				friendData.put("profile_picture", friends.get(i).getProfile_picture());
				data.put(friendData);
			}
			response.put("friends", data);
			return ResponseEntity.ok(response.toString()); // Devolver amigos encontrados encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el evento
		}
	}

	@GetMapping("TimeTogether/userIdByEmail")
	public ResponseEntity<String> getUserIdByEmail(@RequestParam(value = "email") String email) {
		Optional<Usuario> userOpt = usuarioRepository.findByMail(email);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", user.getId());
			return ResponseEntity.ok(response.toString());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@PostMapping("TimeTogether/newUser")
	ResponseEntity<String> postUser(@RequestBody String apiInput) {
		JSONObject userData = new JSONObject(apiInput);
		Usuario user = new Usuario();
		user.setAdditional_information(userData.getString("additional_information"));
		user.setAddres(userData.getString("addres"));
		user.setAlergies(userData.getString("alergies"));
		user.setBirthday(userData.getString("birthday"));
		user.setFavourite_color(userData.getString("favourite_color"));
		List<String> friends = userData.getJSONArray("friends").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		user.setFriends(friends);
		user.setHobbies(userData.getString("hobbies"));
		user.setName(userData.getString("mail"));
		user.setName(userData.getString("name"));
		user.setPassword(userData.getString("password"));
		user.setProfile_picture(userData.getString("profile_picture"));
		JSONObject sizes = userData.getJSONObject("sizes");
		Tallas sizeData = new Tallas();
		sizeData.setShirt(sizes.getInt("shirt"));
		sizeData.setTrousers(sizes.getInt("trousers"));
		sizeData.setShoes(sizes.getInt("shoes"));
		user.setSizes(sizeData);
		user.setSurname(userData.getString("surname"));
		List<String> groups = userData.getJSONArray("groups").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		user.setGroups(groups);
		usuarioRepository.save(user);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@PostMapping("TimeTogether/newGroup")
	ResponseEntity<String> postGroup(@RequestBody String apiInput) {
		JSONObject groupData = new JSONObject(apiInput);
		Grupo group = new Grupo();
		group.setDescription(groupData.getString("description"));
		List<String> events = groupData.getJSONArray("events").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		group.setEvents(events);
		List<String> members = groupData.getJSONArray("members").toList().stream().map(Object::toString)
				.collect(Collectors.toList());
		group.setMembers(members);
		group.setName(groupData.getString("name"));
		group.setColor(groupData.getString("color"));
		grupoRepository.save(group);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@PostMapping("TimeTogether/newEvent")
	ResponseEntity<String> postEvent(@RequestBody String apiInput) {
		JSONObject eventData = new JSONObject(apiInput);
		Evento event = new Evento();
		event.setDate(eventData.getString("date"));
		event.setDescription(eventData.getString("description"));
		event.setLocation(eventData.getString("location"));
		event.setName(eventData.getString("name"));
		eventoRepository.save(event);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@PutMapping("TimeTogether/updateUser/{userId}")
	ResponseEntity<String> updateUser(@PathVariable String userId, @RequestBody String apiInput) {
		Optional<Usuario> userOptional = usuarioRepository.findById(userId);
		if (userOptional.isPresent()) {
			Usuario user = userOptional.get();
			JSONObject userData = new JSONObject(apiInput);

			// Actualiza los campos del usuario con los datos recibidos
			user.setAdditional_information(
					userData.optString("additional_information", user.getAdditional_information()));
			user.setAddres(userData.optString("addres", user.getAddres()));
			user.setAlergies(userData.optString("alergies", user.getAlergies()));
			user.setBirthday(userData.optString("birthday", user.getBirthday()));
			user.setFavourite_color(userData.optString("favourite_color", user.getFavourite_color()));

			if (userData.has("friends")) {
				List<String> friends = userData.getJSONArray("friends").toList().stream().map(Object::toString)
						.collect(Collectors.toList());
				user.setFriends(friends);
			}

			user.setHobbies(userData.optString("hobbies", user.getHobbies()));
			user.setMail(userData.optString("mail", user.getMail())); // Asegúrate de tener un campo para el correo si
																		// es necesario
			user.setName(userData.optString("name", user.getName()));
			user.setPassword(userData.optString("password", user.getPassword()));
			user.setProfile_picture(userData.optString("profile_picture", user.getProfile_picture()));

			if (userData.has("sizes")) {
				JSONObject sizes = userData.getJSONObject("sizes");
				Tallas sizeData = user.getSizes(); // Suponiendo que siempre hay un objeto Tallas inicializado
				sizeData.setShirt(sizes.optInt("shirt", sizeData.getShirt()));
				sizeData.setTrousers(sizes.optInt("trousers", sizeData.getTrousers()));
				sizeData.setShoes(sizes.optInt("shoes", sizeData.getShoes()));
				user.setSizes(sizeData);
			}

			user.setSurname(userData.optString("surname", user.getSurname()));

			if (userData.has("groups")) {
				List<String> groups = userData.getJSONArray("groups").toList().stream().map(Object::toString)
						.collect(Collectors.toList());
				user.setGroups(groups);
			}

			// Guarda el usuario actualizado en la base de datos
			usuarioRepository.save(user);
			return ResponseEntity.ok().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@PostMapping("TimeTogether/eventsByUserAndDate")
	public ResponseEntity<String> getEventsByUserAndDate(@RequestBody String requestBody) {
		JSONObject request = new JSONObject(requestBody);
		String userId = request.getString("userId");
		String dateString = request.getString("date");
		LocalDate date;
		try {
			date = LocalDate.parse(dateString);
		} catch (DateTimeParseException e) {
			return ResponseEntity.badRequest().body("Invalid date format");
		}

		Optional<Usuario> userOpt = usuarioRepository.findById(userId);
		if (!userOpt.isPresent()) {
			return ResponseEntity.notFound().build();
		}

		Usuario user = userOpt.get();
		List<String> userGroups = user.getGroups();
		List<Evento> allEvents = new ArrayList<>();

		for (String groupId : userGroups) {
			Optional<Grupo> groupOpt = grupoRepository.findById(groupId);
			groupOpt.ifPresent(grupo -> {
				List<String> eventIds = grupo.getEvents();
				for (String eventId : eventIds) {
					Optional<Evento> eventOpt = eventoRepository.findById(eventId);
					eventOpt.ifPresent(evento -> {
						if (evento.getDate().equals(date.toString())) {
							allEvents.add(evento);
						}
					});
				}
			});
		}

		JSONArray eventsJsonArray = new JSONArray();
		for (Evento event : allEvents) {
			JSONObject eventJson = new JSONObject();
			eventJson.put("id", event.getId());
			eventJson.put("date", event.getDate());
			eventJson.put("description", event.getDescription());
			eventJson.put("location", event.getLocation());
			eventJson.put("name", event.getName());
			eventsJsonArray.put(eventJson);
		}

		JSONObject response = new JSONObject();
		response.put("events", eventsJsonArray);

		return ResponseEntity.ok(response.toString());
	}

	@PostMapping("TimeTogether/addGroupToUsers")
	public ResponseEntity<String> addGroupToUsersByName(@RequestBody String requestBody) {
	    try {
	        JSONObject requestJson = new JSONObject(requestBody);
	        String groupName = requestJson.getString("groupName");
	        JSONArray userIds = requestJson.getJSONArray("userIds");
	        List<String> userIdList = userIds.toList().stream()
	                .map(Object::toString)
	                .collect(Collectors.toList());

	        // Buscar el grupo por nombre para obtener el ID
	        Optional<Grupo> groupOpt = grupoRepository.findByName(groupName);
	        if (!groupOpt.isPresent()) {
	            return ResponseEntity.badRequest().body("Grupo no encontrado con el nombre: " + groupName);
	        }

	        String groupId = groupOpt.get().getId();
	        List<Usuario> usersToUpdate = new ArrayList<>();
	        for (String userId : userIdList) {
	            Optional<Usuario> userOpt = usuarioRepository.findById(userId);
	            if (userOpt.isPresent()) {
	                Usuario user = userOpt.get();
	                List<String> groups = user.getGroups();
	                if (!groups.contains(groupId)) {
	                    groups.add(groupId);
	                    user.setGroups(groups);
	                    usersToUpdate.add(user);
	                }
	            } else {
	                return ResponseEntity.badRequest().body("Usuario no encontrado con el ID: " + userId);
	            }
	        }

	        if (!usersToUpdate.isEmpty()) {
	            usuarioRepository.saveAll(usersToUpdate);
	            return ResponseEntity.ok("Grupo '" + groupName + "' agregado exitosamente a los usuarios.");
	        } else {
	            return ResponseEntity.ok("No se realizaron cambios.");
	        }
	    } catch (Exception e) {
	        return ResponseEntity.badRequest().body("Error en el formato de la solicitud: " + e.getMessage());
	    }
	}

}

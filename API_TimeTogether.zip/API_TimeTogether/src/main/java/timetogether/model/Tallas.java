package timetogether.model;

public class Tallas {
	private int shirt;
	private int trousers;
	private int shoes;
	public int getShirt() {
		return shirt;
	}
	public void setShirt(int shirt) {
		this.shirt = shirt;
	}
	public int getTrousers() {
		return trousers;
	}
	public void setTrousers(int trousers) {
		this.trousers = trousers;
	}
	public int getShoes() {
		return shoes;
	}
	public void setShoes(int shoes) {
		this.shoes = shoes;
	}
	
	

	

}
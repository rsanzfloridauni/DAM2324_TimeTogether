package timetogether.repository;

import org.json.JSONObject;
import org.springframework.data.mongodb.repository.MongoRepository;

import timetogether.model.Grupo;

public interface GrupoRepository extends MongoRepository<Grupo, String> {
	//Metodos
}

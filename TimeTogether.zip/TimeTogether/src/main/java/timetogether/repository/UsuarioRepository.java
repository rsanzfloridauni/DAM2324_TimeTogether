package timetogether.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import timetogether.model.Usuario;

public interface UsuarioRepository extends MongoRepository<Usuario, String>{
	//Metodos
	@Query("{ 'mail': ?0, 'password': ?1 }")
    Optional<Usuario> findByMailAndPassword(String mail, String password);

	Optional<Usuario> findByMail(String apiInput);
}

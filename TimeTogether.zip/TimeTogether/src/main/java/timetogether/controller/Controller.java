package timetogether.controller;

import java.util.Optional;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import timetogether.model.Grupo;
import timetogether.model.Usuario;
import timetogether.repository.EventoRepository;
import timetogether.repository.GrupoRepository;
import timetogether.repository.UsuarioRepository;

@RestController
public class Controller {

	@Autowired
	private UsuarioRepository usuarioRepository;
	@Autowired
	private GrupoRepository grupoRepository;
	@Autowired
	private EventoRepository eventoRepository;

	@GetMapping("TimeTogether/user")
	ResponseEntity<String> getUser(@RequestParam(value = "mail") String apiInput) {
		JSONObject userData = new JSONObject(apiInput);
		//Optional<Usuario> userOpt = usuarioRepository.findByMailAndPassword(userData.getString("mail"),userData.getString("password"));
		Optional<Usuario> userOpt = usuarioRepository.findByMail(apiInput);
		if (userOpt.isPresent()) {
			Usuario user = userOpt.get();
			JSONObject response = new JSONObject();
			response.put("id", user.getId());
			response.put("name", user.getName());
			response.put("groups", user.getGroups().toArray());
			response.put("additional_information", user.getAdditional_information());
			response.put("addres", user.getAddres());
			response.put("alergies", user.getAlergies());
			response.put("birthday", user.getBirthday());
			response.put("favourite_color", user.getFavourite_color());
			response.put("friends", user.getFriends().toArray());
			response.put("hobbies", user.getHobbies());
			response.put("mail", user.getMail());
			response.put("password", user.getPassword());
			response.put("profile_picture", user.getProfile_picture());
			response.put("sizes", user.getSizes());
			response.put("surname", user.getSurname());
			response.put("favourite_groups", user.getFavourite_groups().toArray());
			return ResponseEntity.ok(response.toString()); // Devolver usuario encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el usuario
		}
	}

	@GetMapping("TimeTogether/group")
	ResponseEntity<String> getGroup(@RequestParam(value = "id") String apiInput) {
		Optional<Grupo> group = grupoRepository.findById(apiInput);
		if (group != null) {
			JSONObject response = new JSONObject();

			return ResponseEntity.ok(response.toString()); // Devolver usuario encontrado
		} else {
			return ResponseEntity.notFound().build(); // Devolver respuesta 404 si no se encuentra el usuario
		}
	}
}

package timetogether.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Usuarios")
public class Usuario {

	@Id
	private String id;
	private String name;
	private String surname;
	private String mail;
	private String password;
	private List<String> friends;
	private List<String> groups;
	private List<String> favourite_groups;
	private String favourite_color;
	private Tallas sizes;
	private String hobbies;
	private String profile_picture;
	private String alergies;
	private String additional_information;
	private String addres;
	private String birthday;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<String> getFriends() {
		return friends;
	}

	public void setFriends(List<String> friends) {
		this.friends = friends;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	public List<String> getFavourite_groups() {
		return favourite_groups;
	}

	public void setFavourite_groups(List<String> favourite_groups) {
		this.favourite_groups = favourite_groups;
	}

	public String getFavourite_color() {
		return favourite_color;
	}

	public void setFavourite_color(String favourite_color) {
		this.favourite_color = favourite_color;
	}

	public Tallas getSizes() {
		return sizes;
	}

	public void setSizes(Tallas sizes) {
		this.sizes = sizes;
	}

	public String getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}

	public String getProfile_picture() {
		return profile_picture;
	}

	public void setProfile_picture(String profile_picture) {
		this.profile_picture = profile_picture;
	}

	public String getAlergies() {
		return alergies;
	}

	public void setAlergies(String alergies) {
		this.alergies = alergies;
	}

	public String getAdditional_information() {
		return additional_information;
	}

	public void setAdditional_information(String additional_information) {
		this.additional_information = additional_information;
	}

	public String getAddres() {
		return addres;
	}

	public void setAddres(String addres) {
		this.addres = addres;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

}

import { useState } from 'react';
import { View, Text, Switch, StyleSheet, TouchableOpacity } from 'react-native';

const Settings = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [lightMode, setLightMode] = useState(false);
  const [spanish, setSpanish] = useState(false);
  const [english, setEnglish] = useState(false);
  const [valencia, setValencia] = useState(false);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <View style={[styles.sectionContainer, styles.containerBackground]}>
        <Text style={styles.sectionTitle}>Modify user data</Text>
        <TouchableOpacity style={styles.buttonContainer}>
          <Text style={styles.buttonText}>+</Text>
        </TouchableOpacity>
      </View>

      <View style={[styles.sectionContainer, styles.containerBackground]}>
        <Text style={styles.sectionTitle}>Screen</Text>
        <View style={styles.switchContainer}>
          <Text style={styles.switchText}>Dark Mode</Text>
          <Switch value={darkMode} onValueChange={setDarkMode} />
        </View>
        <View style={styles.switchContainer}>
          <Text style={styles.switchText}>Light Mode</Text>
          <Switch value={lightMode} onValueChange={setLightMode} />
        </View>

      </View>

      <View style={[styles.sectionContainer, styles.containerBackground]}>
        <Text style={styles.sectionTitle}>Language</Text>
        <View style={styles.switchContainer}>
          <Text style={styles.switchText}>Spanish</Text>
          <Switch value={spanish} onValueChange={setSpanish} />
        </View>
        <View style={styles.switchContainer}>
          <Text style={styles.switchText}>English</Text>
          <Switch value={english} onValueChange={setEnglish} />
        </View>
        <View style={styles.switchContainer}>
          <Text style={styles.switchText}>Valencià</Text>
          <Switch value={valencia} onValueChange={setValencia} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  sectionContainer: {
    marginBottom: 20,
    borderRadius: 10,
    padding: 10,
  },
  containerBackground: {
    backgroundColor: '#E2E1EC',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 20,
    marginRight: 20,
  },
  buttonContainer: {
    position: 'absolute',
    right: 10,
    top: 8,
    backgroundColor: 'gray',
    borderRadius: 20,
    width: 35,
    height: 35,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 10,
  },
  buttonText: {
    fontSize: 24,
    color: 'white',
    lineHeight: 30,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    marginRight: 20,
    fontSize: 30,
  },
  switchText: {
    fontSize: 18,
    marginLeft: 20,
  },
});

export default Settings;

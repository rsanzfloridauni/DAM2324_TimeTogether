import { View, StyleSheet, Image, Text, ScrollView, } from 'react-native';
import * as React from 'react';
import {  Button, TextInput,IconButton } from 'react-native-paper';

export default function Login(props) {
  const [mail, setMail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [viewPassword, setViewPassword] = React.useState(true);
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../image/logo.png')} />
 <ScrollView style={styles.scroll}>
      <TextInput
       style={styles.input}
        mode="outlined"
        label="Email"
        value={mail}
       theme={{ colors: { primary: '#EF9009' } }}
        onChangeText={(mail) => setMail(mail)}
      />

           <TextInput
        style={styles.input}
        mode="outlined"
        secureTextEntry={viewPassword}
        label="Password"
        value={password}
        right={
          <TextInput.Icon
            name={viewPassword ? 'eye-off' : 'eye'}
            onPress={() => setViewPassword(!viewPassword)}
          />
        }
        theme={{ colors: { primary: '#EF9009' } }}
        onChangeText={setPassword}
      />


      <Text style={styles.textForgot}>Has olvidado la contraseña?</Text>

      <Button
        style={styles.button}
        mode="contained"
        color="#304999"
        labelStyle={styles.text}
        onPress={() => props.navigation.navigate('ScreenTab')}>  
        Iniciar Sesion
      </Button>

      <Button
        style={styles.button}
        mode="contained"
        color="#304999"
        labelStyle={styles.text}
        onPress={() => props.navigation.navigate('SingUp')}>    
        Crear cuenta
      </Button>
       </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
    alignItems: 'center',
    textAlign:'center'
  },
scroll:{

    textAlign:'center'
},
  logo: {
    height: 300,
    width: 300,
  },

  button: {
    margin: 10,
    height: 50,
    width: 250,
    borderRadius: 15,
  },

  text: {
    textTransform: 'none',
    fontSize: 18,
  },

  textForgot: {
    color: 'blue',
    fontSize: 12,
    marginBottom: 12,
    textAlign:'center'
  },
    input: {
      flex: 2,
    marginBottom: 10,
    width:250
  },
});

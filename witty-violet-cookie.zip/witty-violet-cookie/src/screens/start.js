import { View, StyleSheet, Image } from 'react-native';
import { ActivityIndicator, Button } from 'react-native-paper';
export default function App(props) {
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../image/logo.png')} />
      <ActivityIndicator animating={true} color={'#EF9009'} size={100} />
       <Button onPress={() =>  props.navigation.navigate('Login')}>
       Pzcvsdvasdvsdv</Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
    alignItems: 'center',
  },

  logo: {
    height: 300,
    width: 300,
  }


});

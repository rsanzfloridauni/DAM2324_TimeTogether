import { View, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Button } from 'react-native-paper';
import * as React from 'react';

import Friend from '../../components/friend';

export default function Friends({navigation}) {
  const [names, setNames] = React.useState(['Pepe', 'Juan']);

  return (
    <View style={styles.container}>
      <View style={styles.panel}>
        <ScrollView>
          {names.map((name, index) => (
            <TouchableOpacity onPress={() => navigation.navigate("FriendsInfo")}>
            <Friend key={index} imageSource={require('../image/logo.png')} name={name} />
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <Button mode="contained" style={styles.button} >
        Agregar amigo
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 20,
    alignItems: 'center',
  },
  button: {
    backgroundColor: '#304999',
    borderRadius: 15,
    margin: 5
  },
  panel: {
    backgroundColor: '#C9C9C9',
    flex: 1,
    width: '100%',
    padding: 20,
    borderRadius: 15,
  },
});

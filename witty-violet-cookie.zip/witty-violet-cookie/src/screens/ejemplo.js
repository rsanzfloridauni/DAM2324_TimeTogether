import Friends from './friends.js';
import Group from './group';
import NewGroup from './newGroup';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';

//import { ScreensProvider } from './src/screens/ScreensContext';
import 'react-native-gesture-handler';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Ionicons from 'react-native-vector-icons/Ionicons';


const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();


export default function Ejemplo({navigation}) {
  return (
    <NavigationContainer independent={true}>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Amics') {
              iconName = focused ? 'ios-person' : 'ios-person-outline';
            } else if (route.name === 'Events') {
              iconName = focused ? 'ios-calendar' : 'ios-calendar-outline';
            } else if (route.name === 'Ajustes') {
              iconName = focused ? 'ios-settings' : 'ios-settings-outline';
            }
            return <Ionicons name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{
          tabBarActiveTintColor: '#666666',
          tabBarInactiveTintColor: 'rgba(128, 128, 128, 0.5)',
        }}>
        <Tab.Screen name="Amics" component={Friends} />
        <Tab.Screen name="Events" component={Group} />
        <Tab.Screen name="Ajustes" component={Group} />
       
      </Tab.Navigator>

    </NavigationContainer>
  );
}
